readme.md
diff between version 13.3 (<) and version 13.4 (>)
10c10
< 	* last tested NVDA version: 2024.1
---
> 	* last tested NVDA version: 2024.4
114c114
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-13.3.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-13.4.4.nvda-addon
