diff between version 11.4.2 (<) and version 12.0 (>):
9,10c9,10
< 	* minimum supported NVDA version: 2020.4
< 	* last tested NVDA version: 2022.4
---
> 	* minimum supported NVDA version: 2021.1
> 	* last tested NVDA version: 2023.1
21,22c21,22
< * Display of the list of icons in the notification area ,
< * Display of the windows list of running applications,
---
> 
> * Display of the list of icons in the notification area or windows of applications launched],
23a24
> * Announcement or display of information about the application under focus, such as its version, the active configuration profile, loaded add-on,
28,36c29,36
< 	* commands for the tables:
< 		* announce the cells of a row /column , go to first/last cell in the row/current column, move the column/row preceding or following with announcement possible of the cells in that row/column,
< 		* announcement of the URL of the document,
< 		* navigate in loop,
< 
< 
< * Announcement of the function associated with editing commands style Copy, Paste, etc.,
< * Announcement of the name of the folder pre-selected in the dialog boxes like "Open","Save", "Save as",etc.,
< * display of information on the focused application:
---
> 	* announcement of the address (URL) of the document,
> 	* option to browse in a loop in search of a next or previous item,
> 	* scripts to click at the current position of the browser object,
> 	* scripts for tables:
> 		* announcement of the position of the current cell,
> 		* move to the next or previous column / row with reading of the cells composing it,
> 		* move to the first / last cell of the row / column (keep for NVDA versions lower than 2022.2),
> 		* announcement of the cells of the current column / row.
38,40d37
< 	* the current profile configuration,
< 	* the name and version number of the application,
< 	* the add-on loaded for the application,
42,45c39,42
< 
< *	NVDA logs tools:
< 	* Opening the previous or current log,
< 	* copy of the path of these in the clipboard.
---
> * Announcement of the function associated with editing commands style Copy, Paste, etc with:
>  * adding the selected text to the clipboard,
>  * emptying the clipboard,
>  * improvement of the NVDA base script "NVDA+c" which announces the text in the clipboard,
47a45,46
> * Announcement of the pre-selected folder in the "Open, Save", "Save as" style dialog boxes,
> * Open previous or current NVDA log and copy their path to clipboard,
51a51
> * restarting NVDA in "debugging" logging level by simple input gesture,
53,57c53,57
< * fast switching of voice profile,
< * remanence of the modifier keys,
< * shutdown, reboot or Hibernate the computer,
< * control the main or NVDA volume:
< 
---
> * quick voice profile switching,
> * persistence of NVDA and modification keys and specific persistence for the gmail.com site,
> * shutdown, restart or Hibernate the computer,
> * management of input gestures configured by user,
> * sound control] (Windows 10 only):
59,62c59,71
< 	* establishment of the main Windows or NVDA volume at the start of the add-on,
< 	* modification of main volume or audio stream's volume of focused application.
< 	* automatic recovery of the main volume and NVDA when the extension is loaded,
< 	* orientation of NVDA audio output,
---
> 	* manually or automatically establish the main sound and that of the NVDA audio stream,
> 	* modify the level of the main volume or that of the audio stream of the application under focus,
> 	* automatic recovery of the main volume and NVDA when loading the extension,
> 	* temporary use of an audio output device without impacting the NVDA configuration,
> 	* orientation of the application and NVDA audio output,
> 	* orientation of application and NVDA audio output,
> 
> 
> * Tools for development of add-on,
> * Complements regarding the date and time:
> 	* copy of the date and time to the clipboard,
> 	* Announce the time on the Windows clock with seconds,
> 	* announcement of the time independent of the punctuation level.
65,66d73
< * Tools for development of add-on.
< * supplements regarding the date and time: copy date and time to clipboard, report time with seconds
69,70d75
< * announcement of the cursor position in the edit boxes,
< * temporary use of an audio output device without impacting the NVDA configuration,
77,79c82,86
< * proclaim the word focused when deleting a word (for NVDA versions lower than 2020.3),
< * automatically maximize the foreground window,
< * announce punctuations and symbols when moving by word in a document.
---
> * automatic window maximization,
> * systematic announcement of punctuation marks when moving by word,
> * possibility of signaling spelling errors by a double beep or by a voice announcement instead of the sound emitted by NVDA.
> * possibility to block the "Insert" and "Caps lock" keys,
> * Pronunciation of non-alphanumeric characters when per-character keyboard echo is disabled.
84,88c91,95
< * report, with a sound, the registration of an error in the NVDA log also for the final versions and release candidate of NVDA,
< * Caption dialog title with the name of the addon,
< * Do not take account of the option called Report object descriptions during the display of the dialog box style confirmation,
< * use the numeric keypad's keys conventionally.
< 
---
> * Signaling by a sound of the entry of an error in the log of NVDA,
> * Title of the add-on's dialog boxes with the add-on's summary,
> * configuration of the wait time delay for repeating the same input gesture,
> * possible use of numeric keypad keys as standard,
> * possibility to limit the repetition of keys.
92,94c99,102
< * presentation formatting of the text in a dialog box,
< * sub-menus to explore the program folders or configuration,
< * script to quickly restart NVDA,
---
> * menu to explore user configuration folder or NVDA program folder,
> * presentation of text formatting information in a dialog box instead of an HTML document,
> * Announcement of confirmation style dialog box text even if item description announcement is disabled,
> * announcement of the cursor position in the edit boxes,
97,99c105,111
< * possibility of executing scripts in the "Input gestures" dialog (for versions of NVDA greater than 2020.3),
< * automatic selection of the category in the dialog "Command gestures",
< * Selection of the last parameter used in the synthesizer parameter loop.
---
> * script to display the list of running add-ons,
> * possibility of executing scripts in the "Input gestures" dialog,
> * automatic selection of the category in the dialog "Input gestures",
> * Selection of the last setting  used in the synthesizer settings ring,
> * enhancements  for Windows Explorer:
> 	* a script to announce the access path of the folder or the file which is under the cursor of the Windows explorer, or copy this path in the clipboard.
> 	* a script to announce, going up the folder tree, the name of the folders making up the path of the folder containing the element under the cursor.
102c114
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-11.4.2.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-12.0.nvda-addon
