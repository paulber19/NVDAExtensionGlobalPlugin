diff between version 13.1.3 (<) and version 13.2 (>):
10c10
< 	* last tested NVDA version: 2023.2
---
> 	* last tested NVDA version: 2023.3
22c22
< * Display of the list of icons in the notification area or windows of applications launched],
---
> * Display of the list of icons in the notification area or windows of applications launched,
39,42c39,42
< * Announcement of the function associated with editing commands style Copy, Paste, etc with:
<  * adding the selected text to the clipboard,
<  * emptying the clipboard,
<  * improvement of the NVDA base script "NVDA+c" which announces the text in the clipboard,
---
> * Announcement of the function associated with editing commands style Copy, cut or Paste with:
> 	* adding the selected text to the clipboard,
> 	* emptying the clipboard,
> 	* improvement of the NVDA base script "NVDA+c" which announces the text in the clipboard,
49c49
< * selective announcement of command keyboard keys ,
---
> * selective announcement of command keys,
52c52
< * display of visible elements making up the object in the foreground,
---
> * display of visible elements making up the object in the foreground and possibility to move to or click on the elements,
57c57
< * sound control] (Windows 10 only):
---
> * sound control:
59,60c59,60
< 	* manually or automatically establish the main sound and that of the NVDA audio stream,
< 	* modify the level of the main volume or that of the audio stream of the application under focus,
---
> 	* manually or automatically establish the main sound and that of the NVDA audio source,
> 	* modify the level of the main volume or that of the audio source of the application under focus,
64c64
< 	* orientation of application and NVDA audio output,
---
> 	
106c106
< * possibility of executing scripts in the "Input gestures" dialog,
---
> * possibility of executing scripts from the "Input gestures" dialog,
114c114
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-13.1.3.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-13.2.nvda-addon
