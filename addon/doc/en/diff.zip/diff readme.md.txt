readme.md
diff between version 13.4.6 (<) and version 14.0 (>)
9,10c9,10
< 	* minimum supported NVDA version: 2022.1
< 	* last tested NVDA version: 2024.4
---
> 	* minimum supported NVDA version: 2024.1
> 	* last tested NVDA version: 2025.1
114c114
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-13.4.5.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-14.0.nvda-addon
