readme.md
diff between version 14.1 (<) and version 15.0 (>)
9,10c9,10
< 	* minimum supported NVDA version: 2024.1
< 	* last tested NVDA version: 2025.3
---
> 	* minimum supported NVDA version: 2025.1
> 	* last tested NVDA version: 2026.1
14a15
> [TOC]
114c115
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-14.1.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-15.0.nvda-addon
