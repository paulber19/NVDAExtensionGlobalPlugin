readme.md
diff between version 15.0 (<) and version 15.1 (>)
3c3
< * Author: PaulBer19 (paulber19@laposte.net)
---
> * Author: PaulBer19 <paulber19@laposte.net>
115c115
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-15.0.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-15.1.nvda-addon
