diff between version 11.2 (<) and version 11.3 (>):
10c10
< 	* dernière version de NVDA testée: 2022.1
---
> 	* dernière version de NVDA testée: 2022.2
100c100
< [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-11.2.nvda-addon
---
> [1]: https://github.com/paulber007/AllMyNVDAAddons/raw/master/NVDAExtensionGlobalPlugin/NVDAExtensionGlobalPlugin-11.3.nvda-addon
